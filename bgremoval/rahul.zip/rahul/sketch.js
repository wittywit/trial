let bodySegmentation;
let video;
let segmentation;
let bgImage;
let imageCounter = 0;
let qrCodeImg;

function preload() {
  bodySegmentation = ml5.bodySegmentation("SelfieSegmentation", { maskType: "background" });
}

function setup() {
  let canvas = createCanvas(640, 480);
  canvas.parent('canvasContainer');

  video = createCapture(VIDEO);
  video.size(640, 480);
  video.hide();

  bodySegmentation.detectStart(video, gotResults);

  select('#downloadButton').mousePressed(startCountdown);
  select('#resetButton').mousePressed(resetImage);
}

function draw() {
  if (bgImage) {
    background(bgImage);
  } else {
    background(0);
  }

  if (segmentation) {
    video.mask(segmentation.mask);
    image(video, 0, 0);
  }
}

function selectBackground(imagePath) {
  bgImage = loadImage(imagePath);
}

function startCountdown() {
  setTimeout(downloadImage, 5000);
}

function gotResults(result) {
  segmentation = result;
}

function downloadImage() {
  imageCounter++;
  let filename = `segmented-image-${imageCounter}.png`;
  saveCanvas(filename, 'png');
  let localImageUrl = `https://e3c38842146bfe7a2e26896e8b5f1720.serveo.net/${filename}`;

  if (qrCodeImg) qrCodeImg.remove();

  let qrCodeURL = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(localImageUrl)}`;
  qrCodeImg = createImg(qrCodeURL, 'QR Code to download image');
  qrCodeImg.parent('qrCodeContainer');
}

function resetImage() {
  imageCounter = 0;
  if (qrCodeImg) qrCodeImg.remove();
  bgImage = null;
}
