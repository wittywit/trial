function selectBackground(imagePath) {
    localStorage.setItem('selectedBackground', imagePath);
}

function triggerDownload() {
    localStorage.setItem('action', 'download');
}

function triggerReset() {
    localStorage.setItem('action', 'reset');
}
